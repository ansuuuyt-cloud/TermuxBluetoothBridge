# Termux Bluetooth Bridge (experimental source project)

This is an Android BLE scan bridge intended to run on the same phone as Termux. It does **not** upload watch faces and does not bypass any paid app feature.

## Build status
This environment does not have Android SDK/Gradle build tools installed, so a ready-to-install APK could not be compiled here. This ZIP contains the Android Studio source project.

## Build APK
1. Open this folder in Android Studio on a computer with Android SDK installed.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Android phone.

## Use
1. Open the app, grant Location permission, keep Bluetooth enabled, and leave the app open.
2. In Termux, use:
   `curl http://127.0.0.1:8765/status`
   `curl http://127.0.0.1:8765/scan`
   wait 8 seconds, then:
   `curl http://127.0.0.1:8765/devices`

## Limitations
- Experimental starter project; it has not been compiled or device-tested.
- It currently provides BLE scanning only, not GATT connect/read/write.
- Android 11 BLE scanning requires location permission and system Location may need to be enabled.
- This cannot confirm a watch-face upload path or defeat NoiseFit Premium checks.
