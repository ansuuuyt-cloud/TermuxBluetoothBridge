package com.example.termuxbtbridge;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CopyOnWriteArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private final CopyOnWriteArrayList<JSONObject> devices = new CopyOnWriteArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private volatile boolean scanning = false;
    private volatile String lastError = "";
    private TextView status;
    private ServerSocket server;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 36, 24, 24);
        TextView title = new TextView(this);
        title.setText("Termux Bluetooth Bridge");
        title.setTextSize(24);
        TextView desc = new TextView(this);
        desc.setText("BLE scanner + localhost API\nKeep this app open while using Termux. API: http://127.0.0.1:8765");
        desc.setTextSize(16);
        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 28, 0, 0);
        root.addView(title); root.addView(desc); root.addView(status);
        setContentView(root);
        BluetoothManager bm = (BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = bm.getAdapter();
        requestNeededPermissions();
        startHttpServer();
        updateStatus("Starting bridge…");
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            java.util.ArrayList<String> p = new java.util.ArrayList<>();
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                p.add(Manifest.permission.ACCESS_FINE_LOCATION);
            if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 5);
        }
    }

    private void updateStatus(String s) { handler.post(() -> status.setText(s)); }

    private JSONObject deviceJson(BluetoothDevice d, int rssi) {
        JSONObject o = new JSONObject();
        try { o.put("name", d.getName() == null ? "" : d.getName()); } catch(Exception ignored){}
        try { o.put("address", d.getAddress()); } catch(Exception ignored){}
        try { o.put("rssi", rssi); } catch(Exception ignored){}
        return o;
    }

    private synchronized String scanNow() {
        if (adapter == null) { lastError = "Bluetooth adapter unavailable"; return lastError; }
        if (!adapter.isEnabled()) { lastError = "Bluetooth is off"; return lastError; }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            lastError = "Location permission not granted"; return lastError;
        }
        try {
            scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { lastError = "BLE scanner unavailable"; return lastError; }
            devices.clear(); lastError = ""; scanning = true;
            scanCallbackRef = new ScanCallback() {
                @Override public void onScanResult(int type, ScanResult result) {
                    BluetoothDevice d = result.getDevice();
                    String address = d.getAddress();
                    boolean found = false;
                    for (JSONObject item : devices) {
                        if (address.equals(item.optString("address"))) {
                            devices.remove(item); break;
                        }
                    }
                    devices.add(deviceJson(d, result.getRssi()));
                }
                @Override public void onScanFailed(int errorCode) {
                    lastError = "BLE scan failed, code=" + errorCode; scanning = false;
                }
            });
            handler.postDelayed(() -> {
                try { if (scanner != null && scanCallbackRef != null) scanner.stopScan(scanCallbackRef); } catch(Exception ignored){}
                scanning = false;
                updateStatus("Scan finished. Devices: " + devices.size() + "\nAPI: http://127.0.0.1:8765/devices");
            }, 8000);
            updateStatus("Scanning BLE devices for 8 seconds…");
            return "Scan started (8 seconds)";
        } catch (Exception e) {
            lastError = e.getClass().getSimpleName() + ": " + e.getMessage();
            scanning = false; return lastError;
        }
    }

    private ScanCallback scanCallbackRef;

    private void startHttpServer() {
        Thread t = new Thread(() -> {
            try {
                server = new ServerSocket(8765, 10, java.net.InetAddress.getByName("127.0.0.1"));
                updateStatus("Bridge running on 127.0.0.1:8765\nOpen Termux and use curl.");
                while (!server.isClosed()) {
                    Socket client = server.accept();
                    new Thread(() -> handle(client)).start();
                }
            } catch(Exception e) { updateStatus("Local API error: " + e.getMessage()); }
        }, "bridge-http");
        t.setDaemon(true); t.start();
    }

    private void handle(Socket s) {
        try (Socket client = s) {
            client.setSoTimeout(2500);
            BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
            String first = in.readLine();
            if (first == null) return;
            String path = first.split(" ")[1];
            String body;
            int code = 200;
            if (path.equals("/")) {
                body = "{\"app\":\"Termux BT Bridge\",\"endpoints\":[\"/status\",\"/scan\",\"/devices\"]}";
            } else if (path.equals("/status")) {
                JSONObject o = new JSONObject();
                o.put("ok", true); o.put("scanning", scanning); o.put("deviceCount", devices.size()); o.put("error", lastError);
                body = o.toString();
            } else if (path.equals("/scan")) {
                body = new JSONObject().put("result", scanNow()).toString();
            } else if (path.equals("/devices")) {
                JSONArray a = new JSONArray();
                for (JSONObject d : devices) a.put(d);
                body = new JSONObject().put("devices", a).put("scanning", scanning).put("error", lastError).toString();
            } else { code = 404; body = "{\"error\":\"not found\"}"; }
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            OutputStream out = client.getOutputStream();
            String header = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Not Found") +
                "\r\nContent-Type: application/json; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\nConnection: close\r\nContent-Length: " + bytes.length + "\r\n\r\n";
            out.write(header.getBytes(StandardCharsets.UTF_8)); out.write(bytes); out.flush();
        } catch(Exception ignored) {}
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try { if (scanner != null && scanCallbackRef != null) scanner.stopScan(scanCallbackRef); } catch(Exception ignored){}
        try { if (server != null) server.close(); } catch(Exception ignored){}
    }
}
